<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2021 Amasty (https://www.amasty.com)
 * @package Amasty_Amp
 */


namespace Amasty\Amp\Helper\Swatches;

use Magento\Framework\View\Element\Block\ArgumentInterface;

/**
 * create empty to implement interface
 */
class Media extends \Magento\Swatches\Helper\Media implements ArgumentInterface
{

}
