<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2021 Amasty (https://www.amasty.com)
 * @package Amasty_Amp
 */


namespace Amasty\Amp\Block\Cms\Widget;

class CategoryLink extends \Magento\Catalog\Block\Widget\Link
{

}
