<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2021 Amasty (https://www.amasty.com)
 * @package Amasty_Amp
 */


namespace Amasty\Amp\Block\Cms\Widget;

class CmsLink extends \Magento\Cms\Block\Widget\Page\Link
{

}
