var config = {
    map: {
        '*': {
            mdDraggableFieldArray:   'Magedelight_OneStepCheckout/js/draggable-field-array',
            mdAttributeMetaEdit:    'Magedelight_OneStepCheckout/js/attribute-meta-edit'
        }
    }
};
