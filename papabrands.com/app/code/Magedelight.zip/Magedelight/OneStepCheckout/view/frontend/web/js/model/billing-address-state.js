define(
    [
        'ko'
    ],
    function (
        ko
    ) {
        'use strict';
        return {
            sameAsShipping:ko.observable(true)
        }
    }
);
